<?php
phpinfo();


?>